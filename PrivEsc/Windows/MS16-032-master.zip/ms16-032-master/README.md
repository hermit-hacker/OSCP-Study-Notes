Target requires 2CPUs

https://googleprojectzero.blogspot.co.uk/2016/03/exploiting-leaked-thread-handle.html

Compiled DLLs will spawn cmd.exe

Recompile with a different COMMAND_LINE constant if required...

powershell -C get-hotfix -id KB3139914

powershell -C get-hotfix -id KB314314

Reflective DLL project used for injection. Note that it will call
ExitProcess to prevent the process spinning and causing excessive CPU
usage.

