#pragma once
#ifdef __cplusplus
extern "C" {
#endif
	int main();

#ifdef __cplusplus
}
#endif