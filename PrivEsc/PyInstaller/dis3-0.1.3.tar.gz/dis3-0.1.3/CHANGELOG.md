# Change Log

## [Unreleased]

### Added

- Added class method and static method disassembly from upstream.

## [0.1.1] - 2015-08-30

### Fixed

- Fixed a failing test.

## 0.1.0 - 2015-02-16

### Added

- Initial release.


[Unreleased]: https://github.com/tomxtobin/python-dis3/compare/v0.1.1...HEAD
[0.1.1]: https://github.com/tomxtobin/python-dis3/compare/v0.1.0...v0.1.1
